to zip the folder:

	zip -r [zip_name] [files]
our case:
	zip -r lambda_upload.zip *
